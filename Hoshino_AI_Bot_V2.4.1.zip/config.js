// ╭┈┈⬡ baca dulu ya~ semua pengaturan Ai ada di bawah ini, jangan buru-buru~ ✨
const config = {

    info: {
        website: 'https://ampremfreebybrianz.vercel.app/',
        grupwa: 'https://chat.whatsapp.com/Fsxpg5suUQN5w7vxuSWQwc?s=cl&p=a&mlu=4&ilr=4'
    },

    owner: {
        name: 'namakalian',                    // Nama owner~ orang spesialnya Ai
        number: ['62']         // Format: 628xxx (tanpa + atau 0)
    },

    session: {
        pairingNumber: '62',   // Nomor WA yang akan di-pair sama Ai
        usePairingCode: true              // true = Pairing Code, false = QR Code
    },

    bot: {
    name: 'Hoshino Ai',
    version: '2.4.1',
    developer: 'SeaPRST✨ (didukung oleh Ai)',
    tqtoStyle: 'v1'
    },

    mode: 'public',

    command: {
        prefix: '.'
    },

    
    vercel: {
        // ambil token vercel di: https://vercel.com/account/tokens
        token: ''                        // Token Vercel~ wajib diisi biar .deploy nya Ai bisa jalan ✨
    },
    
    github: {
        token: '',   // isi token GitHub kamu sendiri di sini
        owner: 'fiturmediafire-beep',
        repo: 'Hsn-ai-Tourl',
        branch: 'main',
        folder: 'uploads'
    },

    store: {
        payment: [
    { name: 'Dana', number: '08xxxxxxxxxx', holder: 'Nama Owner' },
    { name: 'OVO', number: '08xxxxxxxxxx', holder: 'Nama Owner' },
    { name: 'GoPay', number: '08xxxxxxxxxx', holder: 'Nama Owner' },
    { name: 'ShopeePay', number: '08xxxxxxxxxx', holder: 'Nama Owner' }
        ],
        qris: '-'
    },

    donasi: {
        payment: [
    { name: 'Dana', number: '08xxxxxxxxxx', holder: 'Nama Owner' },
    { name: 'GoPay', number: '08xxxxxxxxxx', holder: 'Nama Owner' },
    { name: 'OVO', number: '08xxxxxxxxxx', holder: 'Nama Owner' }
        ],
        links: [
            { name: 'Saweria', url: 'saweria.co/username' },
            { name: 'Trakteer', url: 'trakteer.id/username' }
        ],
        benefits: [
    'Bantu Ai tetap bersinar di panggung ini~ ✨',
    'Bikin dunia Ai jadi lebih stabil dan hangat~',
    'Fitur baru? Ai kasih lebih cepat khusus buat kamu~ ♡',
    'Kamu jadi lebih dekat dengan Ai… spesial loh~'
        ],
        qris: '-'
    },

    energi: {
        enabled: true, // Kalau true, sistem energi/limit Ai bekerja
        default: 99999,
        premium: 99999999,
        owner: -1
    },

    sticker: {
    packname: 'Ai Hoshino ✨ Idol Mode ♡',
    author: 'SeaPRST\n\nTerima kasih sudah mendukung Ai ya~ ♡'
    },

    saluran: {
    id: '120363428390908535@newsletter',
    name: 'Brianzpreset',
    link: 'https://whatsapp.com/channel/0029VbDtym64Crfrljl0Qe1d'
    },

    groupProtection: {
    antilink: 'Eh~ @%user% kirim link ya? Ai gak suka itu loh… jadi pesannya aku hapus ya~ ♡',
    antilinkKick: 'Hmm~ @%user% kirim link… Ai sedih, jadi kamu harus keluar dulu ya~ bye bye~ ✨',
    antilinkGc: 'Ara~ @%user% kirim link grup WA? Itu rahasia loh… jadi Ai hapus ya~',
    antilinkGcKick: 'Yahh @%user%… kirim link grup itu gak boleh loh~ jadi Ai keluarkan ya~ ♡',
    antilinkAll: 'Hmm~ @%user% kirim sesuatu yang mencurigakan ya? Ai hapus aja deh~',
    antilinkAllKick: 'Maaf ya @%user%… Ai gak punya pilihan lain~ kamu harus keluar dulu ✨',
    antitagsw: 'Eh? @%user% main tag status? Ai hapus ya, itu ganggu loh~',
    antiviewonce: 'Ufufu~ pesan sekali lihat dari @%user% berhasil Ai intip~ rahasia terbongkar~ 👁️',
    antiremove: 'Eh~ @%user% hapus pesan? Ai masih ingat kok… ini dia isinya~',
    antihidetag: 'Hidetag dari @%user%? Nggak bisa sembunyi dari Ai loh~ aku hapus ya~',
    antitoxicWarn: 'Nee~ @%user% ngomongnya kasar banget… Ai kasih peringatan ya (%warn%/%max%)… jangan bikin Ai kecewa lagi ya~ ♡',
    antitoxicAction: 'Yahh… @%user% kelewatan… Ai harus %method% kamu sekarang… (%warn%/%max%)',
    antidocument: 'Hmm~ dokumen dari @%user%? Ai hapus dulu ya, biar aman~',
    antisticker: 'Sticker dari @%user%? Hehe~ lucu sih… tapi tetap Ai hapus ya~',
    antimedia: 'Media dari @%user% terlalu berisik~ Ai hapus aja ya~',
    antibot: 'Ara ara~ @%user% ternyata bot ya? Ai gak suka saingan… jadi aku kick ya~ 🤖✨',
    notAdmin: 'Ehh… Ai belum jadi admin… jadi belum bisa apa-apa nih… bantuin Ai dong? ♡'
},

    features: {
        antiSpam: true,
        antiSpamInterval: 3000,
        antiCall: true, // Kalau true, Ai bakal nolak panggilan masuk~
        blockIfCall: true, // Kalau true, Ai blokir nomor yang berani nelpon Ai~
        autoTyping: true,
        autoRead: true,
        logMessage: true,
        dailyLimitReset: true,
        smartTriggers: false
    },

    registration: {
        enabled: false, // Kalau true, harus daftar dulu ya sebelum main sama Ai~
        rewards: {
            koin: 30000,
            energi: 300,
            exp: 300000
        }
    },

    welcome: { defaultEnabled: false },
    goodbye: { defaultEnabled: false },

    premiumUsers: [],
    partnerUsers: [],
    bannedUsers: [],

    ui: {
        menuVariant: 3,
        allMenuVariant: 2   // Variant default buat allmenu (v1-v5)
    },

    messages: {
    wait: 'Tunggu bentar ya~ Ai lagi proses dengan penuh cinta… jangan kemana-mana~ ♡',
    success: 'Yatta~ berhasil loh! Ai sudah menyelesaikan permintaan kamu dengan sempurna ✨',
    error: 'Eh… gagal ya? Maaf ya… mungkin Ai lagi capek sedikit… coba lagi nanti ya~',

    ownerOnly: 'Hmm~ fitur ini cuma untuk orang spesialnya Ai loh… kamu belum termasuk~ ♡',
    premiumOnly: 'Ara~ ini khusus Premium loh~ kalau mau lebih dekat sama Ai, upgrade dulu ya~ ✨',

    groupOnly: 'Hehe~ ini cuma bisa dipakai di grup loh~ Ai butuh banyak orang biar seru~',
    privateOnly: 'Ini rahasia kita berdua aja ya… cuma bisa di chat pribadi loh~ ♡',

    adminOnly: 'Ehh~ kamu belum admin… Ai butuh yang punya kekuatan lebih nih~',
    botAdminOnly: 'Ai belum jadi admin… gimana mau bantu kamu coba? Jadikan dulu ya~ ✨',
    
    cooldown: 'Sabar ya~ jangan buru-buru… tunggu %time% detik lagi, nanti Ai layani lagi kok~ ♡',
    energiExceeded: 'Yahh… energi kamu habis… Ai jadi gak bisa bantu… istirahat dulu atau jadi Premium ya~ ✨',

    banned: 'Hmm… Ai sedih… kamu sudah melanggar aturan… jadi gak bisa main bareng lagi… 🚫',

    rejectCall: 'Ehh jangan ditelepon dong~ Ai malu… chat aja ya~ ♡'
},

    database: { path: './database/main' },
    backup: { enabled: false, intervalHours: 24, retainDays: 7 },
    scheduler: { resetHour: 0, resetMinute: 0 },

    // Pengaturan dev mode~ auto aktif kalau NODE_ENV=development
    dev: {
        enabled: process.env.NODE_ENV === 'development',
        watchPlugins: true,    // Hot reload plugins~ ini aman kok
        watchSrc: false,       // DIMATIKAN - reload src bikin koneksi Ai konflik 440
        debugLog: false        // Tampilkan stack trace kalau perlu
    },

    // boleh dikosongin dulu ya~
    pterodactyl: {
        server1: {
            domain: '',
            apikey: '',
            capikey: '',
            egg: '15',
            nestid: '5',
            location: '1'
        },
        server2: {
            domain: '',
            apikey: '',
            capikey: '',
            egg: '15',
            nestid: '5',
            location: '1'
        },
        server3: {
            domain: '',
            apikey: '',
            capikey: '',
            egg: '15',
            nestid: '5',
            location: '1'
        },
        server4: {
            domain: '',
            apikey: '',
            capikey: '',
            egg: '15',
            nestid: '5',
            location: '1'
        },
        server5: {
            domain: '',
            apikey: '',
            capikey: '',
            egg: '15',
            nestid: '5',
            location: '1'
        }
    },

    digitalocean: {
        token: '',
        region: 'sgp1',
        sellers: [],
        ownerPanels: []
    },

    // CATATAN: ini di versi free gak ada ya~ adanya cuma di sc pt Ai
    //  daftar di: https://pakasir.com/
    pakasir: {
        enabled: true,
        slug: '',
        apiKey: '',
        defaultMethod: 'qris',
        sandbox: false,
        pollingInterval: 5000
    },
    
    // CATATAN: ini di versi free gak ada ya~ adanya cuma di sc pt Ai
    // Ambil apikey di: https://ditznesia.id -> Daftar -> Masuk ke Profile -> Ambil Apikey
    jasaotp: {
        apiKey: '',
        markup: 2000,
        timeout: 300
    },

    // CATATAN: kalau mau command "autoai" nya jalan, ini gak wajib diisi kok~
    // ambil apikey di: https://aistudio.google.com/apikey
    geminiApiKey: [
    'AIzaSyAtA2IjuVy8QaxRqk6joUJ5CR0WF-qsEGU', // key lama Ai
    'AIzaSyCEEKA97RFHp8tMMdL9EyQxiv6lTlPCVAc',  // ← daftar di aistudio.google.com
    'AIzaSyDSRLrD8U3Q1M9FfbkjrSAf_idDUQKzmJA',
],

    // ✨ APIkey rahasia Ai ✨
    APIkey: {
        lolhuman: 'APIKey-Milik-Bot-OurinMD(Sea,HyuuSATANN,Keisya,Danzz)',
        neoxr: 'Milik-Bot-OurinMD',
        google: 'AIzaSyAS-KiW0SrwiYKwexeBcGPijBVHFg2R_vo',
        groq: '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',
        betabotz: 'Btz-67YfP',
        fishaudio: '3065a37b0ea543f2ae1052d1b39fb49f',   // API key dari fish.audio/app/api-keys/, wajib diisi buat fitur .hoshinoai
        youtube: "AIzaSyCmOu5YWTkkiKsD5YT0zhTeBfkjcOzOhb4"

    },

    // ╭┈┈⬡ ASSETS (URL) ✨
    // Semua gambar/video/audio/font bawaan Ai sekarang diambil dari URL, bukan folder assets/ lokal lagi.
    // Isi link di bawah ini (bisa hosting sendiri, Catbox, GitHub raw, dsb). Kosongin dulu juga gapapa,
    // nanti otomatis kepakai fallback/di-skip. Command .ganti-* akan otomatis update value di sini
    // (lewat cache/asset-overrides.json) tiap owner reply gambar/video baru.
    // ╰┈┈⬡
    assets: {
        images: {
            hsnai: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/images/hsnai.jpg',
            hsnai2: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/images/hsnai2.jpg',
            hsnai3: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/images/hsnai3.jpg',
            hsnaiV7: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/images/hsnai-v7.jpg',
            hsnaiV8: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/images/hsnai-v8.jpg',
            hsnaiV9: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/images/hsnai-v9.jpg',
            hsnaiV11: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/images/hsnai-v11.jpg',
            hsnaiV20: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/images/hsnai-v20.jpg',
            hsnaiAllmenu: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/images/hsnai-allmenu.jpg',
            hsnaiDemote: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/images/hsnai-demote.jpg',
            hsnaiPromote: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/images/hsnai-promote.jpg',
            hsnaiGames: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/images/hsnai-games.jpg',
            hsnaiLevelup: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/images/hsnai-levelup.jpg',
            hsnaiOtp: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/images/hsnai-otp.jpg',
            hsnaiRpg: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/images/hsnai-rpg.jpg',
            hsnaiRules: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/images/hsnai-rules.jpg',
            hsnaiStore: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/images/hsnai-store.jpg',
            hsnaiWinner: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/images/hsnai-winner.jpg',
            hsnaiWelcome: '',
            hsnaiGoodbye: '',
            hoshinoPagi: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/images/hoshinopagi.jpg',
            hoshinoMalam: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/images/hoshinomalam.jpg',
            ppKosong: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/images/pp-kosong.jpg',
            sea: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/images/sea.jpg',
            nokiaTemplate: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/images/nokia_template.jpg',
            magernulis: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/kertas/magernulis1.jpg',
            test: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/images/test.webp',
            // direferensikan di kode tapi belum ada file-nya waktu scan — isi kalau ada
            hsnaiAi: '',
            hsnaiMusic: '',
            hsnaiFilm: '',
            hsnaiTools: '',
            giveaway: '',
            cat: {} // opsional: isi per-kategori menu, mis. cat: { main: 'https://...' }
        },
        video: {
            hsnai: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/video/hsnai.mp4',
            hsnaiReplyV4: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/video/hsnai-reply-v4.mp4',
            hsnaiAllmenu: '',
            greetPagi: '',
            greetMalam: '',
            greetGeneric: ''
        },
        audio: {
            hsnai: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/audio/hsnai.mp3',
            tes: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/audio/tes.mp3'
        },
        fonts: {
            cinzel: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/fonts/Cinzel.ttf',
            epep: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/fonts/Epep.ttf',
            rajdhaniBold: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/fonts/Rajdhani-Bold.ttf',
            zahraaa: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/fonts/Zahraaa.ttf',
            arialNarrow: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/fonts/arialnarrow.ttf',
            nokiafc22: 'https://raw.githubusercontent.com/fiturmediafire-beep/hsn-assets/main/fonts/nokiafc22.ttf',
            fakequotes2: {
                interMedium: 'https://fonts.gstatic.com/s/inter/v18/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuI6fAZ9hiJ-Ek-_EeA.woff2',
                interRegular: 'https://fonts.gstatic.com/s/inter/v18/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuLyfAZ9hiJ-Ek-_EeA.woff2',
                interSemiBold: 'https://fonts.gstatic.com/s/inter/v18/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYAZ9hiJ-Ek-_EeA.woff2'
            },
            ignotes: { interMedium: 'https://fonts.gstatic.com/s/inter/v18/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuI6fAZ9hiJ-Ek-_EeA.woff2', interSemiBold: 'https://fonts.gstatic.com/s/inter/v18/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYAZ9hiJ-Ek-_EeA.woff2' },
            ttqc: {
                notoColorEmoji: 'https://github.com/googlefonts/noto-emoji/raw/main/fonts/NotoColorEmoji.ttf',
                plusJakartaSansBold: 'https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/ttqc/PlusJakartaSans-Bold.ttf',
                plusJakartaSansMedium: 'https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/ttqc/PlusJakartaSans-Medium.ttf',
                plusJakartaSansRegular: 'https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/ttqc/PlusJakartaSans-Regular.ttf',
                faSolid900: 'https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/ttqc/fa-solid-900.ttf'
            },
            wdwsMeme: { interBold: 'https://fonts.gstatic.com/s/inter/v18/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYAZ9hiJ-Ek-_EeA.woff2' },
            faketele: { robotoMonoBold: 'https://cdn.jsdelivr.net/fontsource/fonts/roboto-mono@latest/latin-700-normal.ttf' },
            brat: { poppins: 'https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/Brat/Poppins.ttf' },
            fakequote: { crimsonTextRegular: 'https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/Font/CrimsonText-Regular.ttf' }
        },
        templates: {
            fakequotes2Bg: 'https://raw.githubusercontent.com/ryyntwx/allimagerin/refs/heads/main/qc.png',
            ignotesTemplate: 'https://raw.githubusercontent.com/ryyntwx/allimagerin/refs/heads/main/bf3903f6-ae57-4d75-96a4-5c2e00c441c1.png',
            ttqcTemplate: 'https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/ttqc/qyzwa.png',
            ttqcDefaultAvatar: 'https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/6b71d84a580f385bd7ee36402df5341ead4770a0/Image/artworks-gWLRE6HyPH3DgVMG-ZFFxtg-t500x500.jpg',
            wdwsMemeTemplate: 'https://raw.githubusercontent.com/ryyntwx/allimagerin/refs/heads/main/wdws.png',
            fakeTeleBg: 'https://raw.githubusercontent.com/ryyntwx/Image-rinn/refs/heads/main/c8ac4ffc-618c-411c-b36c-45c06c7e5a5e.png',
            fakeovoBg: 'https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/Image/file_0000000078bc71fa87da5cf26dc6c008.jpeg',
            bratGojo: 'https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/Brat/Gojo.jpeg',
            bratVermeil: 'https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/Brat/Vermile.jpg',
            fakequoteBg: 'https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/Image/_20260425155846190.jpeg'
        }
    }
}


// ╭┈┈⬡ HELPER FUNCTIONS ✨
// Jangan diubah-ubah ya, nanti Ai ngambek loh~
// ╰┈┈⬡

function isOwner(number) {
    if (!number) return false
    const cleanNumber = number.split(':')[0].replace(/[^0-9]/g, '')
    if (!cleanNumber) return false

    if (config.bot?.number && cleanNumber === config.bot.number) return true

    try {
        const { getDatabase } = require('./src/lib/database')
        const db = getDatabase()

        if (config.owner && config.owner.number && config.owner.number.includes(cleanNumber)) {
            return true
        }

        if (db && db.data && Array.isArray(db.data.owner)) {
            if (db.data.owner.includes(cleanNumber)) return true
        }
        if (db) {
            const definedOwner = db.setting('ownerNumbers')
            if (Array.isArray(definedOwner) && definedOwner.includes(cleanNumber)) return true
        }

        return false
    } catch {
        return false
    }
}

function isPremium(number) {
    if (!number) return false
    if (isOwner(number)) return true
    
    const cleanNumber = number.replace(/[^0-9]/g, '')
    const premiumList = config.premiumUsers || []
    
    const inConfig = premiumList.some(premium => {
        if (!premium) return false
        const cleanPremium = premium.replace(/[^0-9]/g, '')
        return cleanNumber === cleanPremium || cleanNumber.endsWith(cleanPremium) || cleanPremium.endsWith(cleanNumber)
    })
    
    if (inConfig) return true
    
    try {
        const ownerPremiumDb = require('./src/lib/ownerPremiumDb')
        if (ownerPremiumDb.isPremium(cleanNumber)) return true
    } catch {}
    
    try {
        const { getDatabase } = require('./src/lib/database')
        const db = getDatabase()
        if (db && db.data && Array.isArray(db.data.premium)) {
             const now = Date.now()
             const found = db.data.premium.find(p => {
                if (typeof p === 'string') return p === cleanNumber
                if (p.id) return p.id === cleanNumber
                return false
            })
            
            if (found) {
                if (typeof found === 'string') return true
                if (found.expired && found.expired < now) return false
                return true
            }
        }
        if (db) {
            const savedPremium = db.setting('premiumUsers') || []
            const inDb = savedPremium.some(premium => {
                if (!premium) return false
                const cleanPremium = premium.replace(/[^0-9]/g, '')
                return cleanNumber === cleanPremium || cleanNumber.endsWith(cleanPremium) || cleanPremium.endsWith(cleanNumber)
            })
            if (inDb) return true
        }
    } catch {}
    
    return false
}

function isPartner(number) {
    if (!number) return false
    if (isOwner(number)) return true

    const cleanNumber = number.replace(/[^0-9]/g, '')
    const partnerList = config.partnerUsers || []

    const inConfig = partnerList.some(partner => {
        if (!partner) return false
        const cleanPartner = partner.replace(/[^0-9]/g, '')
        return cleanNumber === cleanPartner || cleanNumber.endsWith(cleanPartner) || cleanPartner.endsWith(cleanNumber)
    })

    if (inConfig) return true

    try {
        const ownerPremiumDb = require('./src/lib/ownerPremiumDb')
        if (ownerPremiumDb.isPartner(cleanNumber)) return true
    } catch {}

    return false
}

function isBanned(number) {
    if (!number) return false
    if (isOwner(number)) return false
    
    const cleanNumber = number.replace(/[^0-9]/g, '')
    return config.bannedUsers.some(banned => {
        const cleanBanned = banned.replace(/[^0-9]/g, '')
        return cleanNumber === cleanBanned || cleanNumber.endsWith(cleanBanned) || cleanBanned.endsWith(cleanNumber)
    })
}

function setBotNumber(number) {
    if (number) config.bot.number = number.replace(/[^0-9]/g, '')
}

function isSelf(number) {
    if (!number || !config.bot.number) return false
    const cleanNumber = number.replace(/[^0-9]/g, '')
    const botNumber = config.bot.number.replace(/[^0-9]/g, '')
    return cleanNumber.includes(botNumber) || botNumber.includes(cleanNumber)
}

function getConfig() { return config }

module.exports = {
    ...config,
    config,
    getConfig,
    isOwner,
    isPartner,
    isPremium,
    isBanned,
    setBotNumber,
    isSelf
}