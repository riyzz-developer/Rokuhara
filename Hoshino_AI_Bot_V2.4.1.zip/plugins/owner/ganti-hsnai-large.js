const fs = require('fs')
const path = require('path')

const pluginConfig = {
    name: 'hsnai-large',
    alias: ['sethsnailarge', 'gantihsnailarge'],
    category: 'owner',
    description: 'Preset: Ganti gambar hsnai.jpg, serta hsnai-v7 hingga hsnai-v11.jpg sekaligus',
    usage: '.hsnai-large (reply/kirim gambar)',
    example: '.hsnai-large',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const isImage = m.isImage || (m.quoted && m.quoted.type === 'imageMessage')
    
    if (!isImage) {
        return m.reply(`🖼️ *ʜsɴᴀɪ ʟᴀʀɢᴇ ᴘʀᴇsᴇᴛ*\n\n> Kirim/reply gambar untuk mengganti kumpulan foto besar (images.hsnai, hsnaiV7, hsnaiV8, hsnaiV9, hsnaiV11) sekaligus.\n> Pastikan rasio gambar sesuai dengan yang diinginkan.`)
    }
    
    await m.react('🕕')
    
    try {
        let buffer
        if (m.quoted && m.quoted.isMedia) {
            buffer = await m.quoted.download()
        } else if (m.isMedia) {
            buffer = await m.download()
        }
        
        if (!buffer) {
            await m.react('❌')
            return m.reply(`❌ *Ara ara~*\n\n> Ai gagal download gambarnya nih... coba lagi ya~ 🥺`)
        }
        
        const targetKeys = [
            'images.hsnai',
            'images.hsnaiV7',
            'images.hsnaiV8',
            'images.hsnaiV9',
            'images.hsnaiV11'
        ]

        // Upload sekali ke Catbox, URL yang sama dipakai untuk semua key
        const { uploadAndSetAsset, setAssetUrl } = require('../../src/lib/assetManager')
        const url = await uploadAndSetAsset(targetKeys[0], buffer, 'hsnai-large.jpg')
        for (const key of targetKeys.slice(1)) setAssetUrl(key, url)
        const targetImages = targetKeys.map(k => 'config.assets.' + k)
        
        await m.react('✅')
        m.reply(`✅ *ʙᴇʀʜᴀsɪʟ*\n\n> Gambar bundle *hsnai-large* berhasil diganti secara massal.\n> Mencakup: ${targetImages.join(', ')}\n> Link baru: ${url}`)
        
    } catch (error) {
        await m.react('❌')
        m.reply(`❌ *Gomen ne~* ✦\n\n> ${error.message}\n\n_Ai udah coba yang terbaik tapi gagal juga... coba lagi nanti ya~ 🌸_`)
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
